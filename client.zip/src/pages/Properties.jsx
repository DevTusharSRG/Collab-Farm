import { useState, useEffect } from 'react';

function Properties() {
    const [properties, setProperties] = useState([]);
    const [filterBuy, setFilterBuy] = useState('');
    const [filterPrice, setFilterPrice] = useState('');
    const [searchQuery, setSearchQuery] = useState('');

    useEffect(() => {
        // Dummy data for properties
        const dummyData = [
            {
                id: 1,
                propertyTitle: "Beautiful House",
                price: "200000",
                companyName: "Dream Homes Inc.",
                image1: "house1.jpg",
                image2: "house2.jpg",
                image3: "house3.jpg"
            },
            {
                id: 2,
                propertyTitle: "Luxury Villa",
                price: "500000",
                companyName: "Luxury Living Realty",
                image1: "villa1.jpg",
                image2: "villa2.jpg",
                image3: "villa3.jpg"
            },
            {
                id: 3,
                propertyTitle: "Cozy Apartment",
                price: "100000",
                companyName: "City Apartments",
                image1: "apartment1.jpg",
                image2: "apartment2.jpg",
                image3: "apartment3.jpg"
            }
        ];

        // Apply filters if any
        let filteredProperties = dummyData.filter(property => {
            if (filterBuy !== '' && property.for !== filterBuy) return false;
            if (filterPrice !== '') {
                const price = parseInt(property.price);
                if (filterPrice === '10000' && (price < 0 || price > 100000)) return false;
                if (filterPrice === '110000' && (price < 100000 || price > 200000)) return false;
                if (filterPrice === '220000' && (price < 200000 || price > 300000)) return false;
            }
            if (searchQuery !== '') {
                const search = searchQuery.toLowerCase();
                if (!property.propertyTitle.toLowerCase().includes(search) && !property.description.toLowerCase().includes(search)) return false;
            }
            return true;
        });

        setProperties(filteredProperties);
    }, [filterBuy, filterPrice, searchQuery]);

    const handleFilterBuyChange = (e) => {
        setFilterBuy(e.target.value);
    };

    const handleFilterPriceChange = (e) => {
        setFilterPrice(e.target.value);
    };

    const handleSearchQueryChange = (e) => {
        setSearchQuery(e.target.value);
    };

    return (
        <div className="mx-auto px-4 lg:px-20">
            {/* Banner */}
            <div className=" p-4">
                <div className="container mx-auto">
                    <span className="float-right">Home / Buy, Sale & Rent</span>
                    <h2 className="text-2xl font-semibold">Buy, Sale & Rent</h2>
                </div>
            </div>
            {/* End Banner */}

            <div className="container mx-auto">
                <div className="flex flex-wrap justify-between mt-4">
                    {/* Filter form */}
                    <div className="w-full md:w-1/4 p-4">
                        {/* Dummy filter form */}
                        <div className="bg-gray-200 shadow p-4">
                            <h4 className="text-lg mb-4">Search for</h4>
                            <div className="mb-4">
                                <input type="text" name="search" className="w-full border py-2 px-3 mb-2" placeholder="Search for Properties" onChange={handleSearchQueryChange} />
                                <button type="button" className="bg-blue-500 text-white py-2 px-4 rounded">Search</button>
                            </div>
                            <div className="mb-4 flex">
                                <div className="w-1/2 pr-2">
                                    <select name="buy" className="w-full border py-2 px-3" onChange={handleFilterBuyChange}>
                                        <option value="">All</option>
                                        <option value="buy">Buy</option>
                                        <option value="rent">Rent</option>
                                    </select>
                                </div>
                                <div className="w-1/2 pl-2">
                                    <select name="price" className="w-full border py-2 px-3" onChange={handleFilterPriceChange}>
                                        <option value="">Price</option>
                                        <option value="10000">Rs 0 - Rs100,000</option>
                                        <option value="110000">Rs 100,000 - Rs200,000</option>
                                        <option value="220000">Rs 200,000 - Rs300,000</option>
                                    </select>
                                </div>
                            </div>
                            <button type="button" className="bg-blue-500 text-white py-2 px-4 rounded w-full">Find Now</button>
                        </div>

                        {/* Dummy Hot Properties Section */}
                        <div className="mt-4 hidden md:block">
                            <h4 className="text-lg font-semibold">Hot Properties</h4>
                            <div className="row">
                                {/* Hot property items */}
                            </div>
                        </div>
                    </div>

                    {/* Property Listings */}
                    <div className="w-full md:w-3/4">
                        <div className="text-lg mb-4">Showing: {properties.length} of 100</div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                            {properties.map(property => (
                                <div key={property.id} className="mb-4">
                                    <div className="bg-white shadow p-4 ">
                                        <img src={`../images/${property.image1}`} alt="Property Image" className="w-full h-48 object-cover mb-4" />
                                        <h5 className="text-xl font-semibold mb-2">{property.propertyTitle}</h5>
                                        <p className="text-lg mb-2">{property.price} Rs</p>
                                        <p className="mb-4">{property.companyName}</p>
                                        <a href="#" className="bg-blue-500 text-white py-2 px-4 rounded">View Details</a>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Properties;
