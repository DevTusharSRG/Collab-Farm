import { useParams } from 'react-router-dom';

function PropertyDetails() {
    const { pid } = useParams();
    
    // This is just dummy data to simulate the fetched property details
    const property = {
        id: pid,
        propertyTitle: "Beautiful House",
        address: "123 Main St",
        price: "200000",
        area: "Dream Homes Inc.",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed fermentum ligula ut nisi viverra, ac tempus arcu sodales.",
        surveyNo: "123",
        image1: "house1.jpg",
        image2: "house2.jpg",
        image3: "house3.jpg"
    };

    return (
        <div className="container mx-auto mt-8 px-4 lg:px-20">
            <div className="max-w-4xl mx-auto">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div>
                        <h2 className="text-3xl font-semibold mb-4">{property.propertyTitle}</h2>
                        <p className="mb-2"><strong>Address:</strong> {property.address}</p>
                        <p className="mb-2"><strong>Price:</strong> Rs {property.price}</p>
                        <p className="mb-2"><strong>Area:</strong> {property.area}</p>
                        <p className="mb-6"><strong>Description:</strong> {property.description}</p>
                        <p className="mb-2"><strong>Survey Number:</strong> {property.surveyNo}</p>
                        <p className="mb-2">View(7/12):ClickHere!</p>
                        <h3 className="text-xl mb-4">Images</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="aspect-w-4 aspect-h-3">
                                <img src={`../images/${property.image1}`} className="object-cover w-full h-full" alt="Property Image" />
                            </div>
                            <div className="aspect-w-4 aspect-h-3">
                                <img src={`../images/${property.image2}`} className="object-cover w-full h-full" alt="Property Image" />
                            </div>
                            <div className="aspect-w-4 aspect-h-3">
                                <img src={`../images/${property.image3}`} className="object-cover w-full h-full" alt="Property Image" />
                            </div>
                        </div>
                        <div className='mt-4'>
                        <a href={`apply.php?pid=${property.id}`} className="inline-block bg-blue-500 text-white py-3 px-6 rounded-md mb-4">Apply Now</a>
                    </div>
                    </div>
                    
                </div>
            </div>
        </div>
    );
}

export default PropertyDetails;
