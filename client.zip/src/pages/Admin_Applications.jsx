export const Admin_Applications = ()=>{
    return (<h1>Admin Admin_Applications</h1>)
}