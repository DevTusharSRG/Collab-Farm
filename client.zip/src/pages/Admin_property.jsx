export const Admin_property = ()=>{
    return (<h1>Admin Admin_property</h1>)
}